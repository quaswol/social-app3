import React, { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
} from "firebase/auth";
import {
  getFirestore,
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
} from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

// Firebase config - buraya kendi Firebase bilgilerini koy
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export default function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [postText, setPostText] = useState("");
  const [file, setFile] = useState(null);
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });

    const q = query(collection(db, "posts"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setPosts(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });

    return () => unsubscribe();
  }, []);

  const handleSignup = () => {
    createUserWithEmailAndPassword(auth, email, password).catch((err) =>
      alert(err.message)
    );
  };

  const handleLogin = () => {
    signInWithEmailAndPassword(auth, email, password).catch((err) =>
      alert(err.message)
    );
  };

  const handleLogout = () => {
    signOut(auth);
  };

  const handlePost = async () => {
    let imageUrl = "";
    if (file) {
      const storageRef = ref(storage, `images/${file.name}`);
      await uploadBytes(storageRef, file);
      imageUrl = await getDownloadURL(storageRef);
    }

    await addDoc(collection(db, "posts"), {
      text: postText,
      imageUrl,
      user: user.email,
      createdAt: new Date(),
    });

    setPostText("");
    setFile(null);
  };

  if (!user) {
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">Giriş / Kayıt</h2>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border p-2 mb-2 w-full"
        />
        <input
          type="password"
          placeholder="Şifre"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border p-2 mb-2 w-full"
        />
        <button
          onClick={handleLogin}
          className="bg-blue-500 text-white px-4 py-2 rounded mr-2"
        >
          Giriş Yap
        </button>
        <button
          onClick={handleSignup}
          className="bg-green-500 text-white px-4 py-2 rounded"
        >
          Kayıt Ol
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Mini Sosyal Uygulama</h1>
      <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded mb-4">
        Çıkış Yap
      </button>

      <div className="mb-4">
        <textarea
          placeholder="Ne düşünüyorsun?"
          value={postText}
          onChange={(e) => setPostText(e.target.value)}
          className="border p-2 w-full mb-2"
        />
        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
        <button
          onClick={handlePost}
          className="bg-blue-500 text-white px-4 py-2 rounded mt-2"
        >
          Paylaş
        </button>
      </div>

      <div>
        {posts.map((post) => (
          <div key={post.id} className="border p-4 mb-4 rounded">
            <p className="font-semibold">{post.user}</p>
            <p>{post.text}</p>
            {post.imageUrl && (
              <img src={post.imageUrl} alt="post" className="mt-2 rounded" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
